
import os
from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QListWidget, QListWidgetItem, QTableWidget, QTableWidgetItem, QHeaderView,
    QLineEdit, QCheckBox, QPushButton, QLabel, QProgressBar, QPlainTextEdit, QMessageBox)
from PyQt6.QtCore import Qt
from core.settings import AppSettings
from core.library import Library
from core.adapters.kuaikan_adapter import KuaikanAdapter
from core.controller import DownloadWorker
from ui.settings_dialog import SettingsDialog

class MainWindow(QMainWindow):
    def __init__(self, settings_path: str, data_dir: str):
        super().__init__()
        self.setWindowTitle("漫画下载器 - 暗色版")
        self.settings_path = settings_path
        self.data_dir = data_dir
        self.s = AppSettings.load(settings_path)
        self.lib = Library(self.s.save_root, data_dir)
        self.adapter = KuaikanAdapter(self.s)
        self.current_topic = None
        self.current_chapters = []
        self.worker: DownloadWorker|None = None

        header = QHBoxLayout()
        self.search = QLineEdit(); self.search.setPlaceholderText("搜索：我的漫画库 / 章节标题")
        self.toggleShowAll = QCheckBox("显示已下载")
        self.toggleShowAll.setChecked(self.s.show_downloaded)
        btnSettings = QPushButton("设置")
        header.addWidget(QLabel("站点：快看"))
        header.addWidget(self.search, 1)
        header.addWidget(self.toggleShowAll)
        header.addWidget(btnSettings)

        btnAddTopic = QPushButton("新增漫画")
        btnSetUrl = QPushButton("设置URL")
        header.addWidget(btnAddTopic)
        header.addWidget(btnSetUrl)

        self.libraryList = QListWidget()
        self.refresh_library()

        self.chapterTable = QTableWidget(0, 7)
        self.chapterTable.setHorizontalHeaderLabels(["选", "序号", "话数", "标题", "状态", "进度", "错误信息"])
        self.chapterTable.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.chapterTable.setSelectionBehavior(self.chapterTable.SelectionBehavior.SelectRows)
        self.chapterTable.setEditTriggers(self.chapterTable.EditTrigger.NoEditTriggers)

        controls = QHBoxLayout()
        self.btnFetch = QPushButton("同步章节")
        self.btnStart = QPushButton("开始下载")
        self.btnPause = QPushButton("暂停")
        self.btnResume = QPushButton("继续")
        self.btnCancel = QPushButton("取消")
        self.btnPause.setEnabled(False); self.btnResume.setEnabled(False); self.btnCancel.setEnabled(False)
        controls.addWidget(self.btnFetch); controls.addStretch(1)
        controls.addWidget(self.btnStart); controls.addWidget(self.btnPause); controls.addWidget(self.btnResume); controls.addWidget(self.btnCancel)

        self.totalProgress = QProgressBar()
        self.totalLabel = QLabel("就绪")
        self.logView = QPlainTextEdit(); self.logView.setReadOnly(True)

        right = QWidget(); rlay = QVBoxLayout(right)
        rlay.addLayout(controls)
        rlay.addWidget(self.chapterTable, 3)
        rlay.addWidget(self.totalProgress)
        rlay.addWidget(self.totalLabel)
        rlay.addWidget(self.logView, 2)

        splitter = QSplitter()
        left = QWidget(); ll = QVBoxLayout(left); ll.addWidget(QLabel("我的漫画库")); ll.addWidget(self.libraryList)
        splitter.addWidget(left); splitter.addWidget(right); splitter.setStretchFactor(1, 3)

        root = QWidget(); rootLay = QVBoxLayout(root); rootLay.addLayout(header); rootLay.addWidget(splitter)
        self.setCentralWidget(root)

        btnSettings.clicked.connect(self.open_settings)
        self.libraryList.itemDoubleClicked.connect(self.pick_topic_from_library)
        self.btnFetch.clicked.connect(self.sync_chapters_clicked)
        self.btnStart.clicked.connect(self.start_download_clicked)
        self.btnPause.clicked.connect(self.pause_clicked)
        self.btnResume.clicked.connect(self.resume_clicked)
        self.btnCancel.clicked.connect(self.cancel_clicked)
        self.search.textChanged.connect(self.apply_filters)
        self.toggleShowAll.stateChanged.connect(self.apply_filters)

        btnAddTopic.clicked.connect(self.add_topic_dialog)
        btnSetUrl.clicked.connect(self.set_topic_url_dialog)

    def log(self, text: str):
        self.logView.appendPlainText(text)

    def refresh_library(self):
        self.libraryList.clear()
        topics = self.lib.list_topics("kuaikan")
        keyword = self.search.text().strip().lower()
        for t in topics:
            if keyword and keyword not in t.title.lower():
                continue
            item = QListWidgetItem(f"{t.title}")
            item.setData(Qt.ItemDataRole.UserRole, t)
            self.libraryList.addItem(item)

    def pick_topic_from_library(self, item: QListWidgetItem):
        t = item.data(Qt.ItemDataRole.UserRole)
        self.current_topic = t
        self.log(f"已选择：{t.title}")
        if not t.topic_url:
            self.log("此条目没有保存过 URL，请在设置中或登录后保存。")
        self.populate_chapters_local(t.title)

    def populate_chapters_local(self, title: str):
        self.chapterTable.setRowCount(0)
        local = self.lib.scan_chapters_local("kuaikan", title)
        for name, entry in sorted(local.items(), key=lambda kv: kv[1].order):
            self._append_chapter_row(dict(order=entry.order, episode_no="", title=name, url="", downloaded_files=entry.downloaded_files, total_files=entry.total_files))

    def _append_chapter_row(self, ch: dict):
        row = self.chapterTable.rowCount()
        self.chapterTable.insertRow(row)
        chk = QTableWidgetItem("")
        chk.setCheckState(Qt.CheckState.Checked if (ch.get("downloaded_files",0)==0) else Qt.CheckState.Unchecked)
        self.chapterTable.setItem(row, 0, chk)
        self.chapterTable.setItem(row, 1, QTableWidgetItem(str(ch.get("order",""))))
        self.chapterTable.setItem(row, 2, QTableWidgetItem(str(ch.get("episode_no",""))))
        self.chapterTable.setItem(row, 3, QTableWidgetItem(ch.get("title","")))
        self.chapterTable.setItem(row, 4, QTableWidgetItem("已存在" if ch.get("downloaded_files",0)>0 else "待开始"))
        prog = QTableWidgetItem("0/0"); prog.setData(Qt.ItemDataRole.UserRole, 0); prog.setData(Qt.ItemDataRole.UserRole+1, 0)
        self.chapterTable.setItem(row, 5, prog)
        self.chapterTable.setItem(row, 6, QTableWidgetItem(""))
        self.chapterTable.item(row, 0).setData(Qt.ItemDataRole.UserRole, ch)

    def sync_chapters_clicked(self):
        if not self.current_topic or not self.current_topic.topic_url:
            QMessageBox.warning(self, "提示", "请先在左侧选择含有 URL 的漫画条目（或手工在设置中配置后登录一次保存）。")
            return
        ok, msg, title = self.adapter.login(self.current_topic.topic_url)
        self.log(f"[登录] {msg}")
        t, chapters = self.adapter.fetch_chapters(self.current_topic.topic_url)
        self.current_chapters = chapters
        self.chapterTable.setRowCount(0)
        local = self.lib.scan_chapters_local("kuaikan", title)
        for ch in chapters:
            downloaded_files = 0
            for name, entry in local.items():
                if name.startswith(f"{ch.get('order',0):03d}"):
                    downloaded_files = entry.downloaded_files
                    break
            row_ch = dict(order=ch.get("order"), episode_no=ch.get("episode_no"), title=ch.get("title"), url=ch.get("url"), downloaded_files=downloaded_files, total_files=0)
            self._append_chapter_row(row_ch)
        self.apply_filters()
        self.lib.upsert_topic("kuaikan", title, self.current_topic.topic_url, os.path.join(self.s.save_root, title))

    def apply_filters(self):
        self.refresh_library()
        show_all = self.toggleShowAll.isChecked()
        kw = self.search.text().strip().lower()
        for r in range(self.chapterTable.rowCount()):
            title = self.chapterTable.item(r, 3).text().lower()
            status = self.chapterTable.item(r, 4).text()
            hide = False
            if kw and kw not in title:
                hide = True
            if not show_all and status in ("已存在", "已完成"):
                hide = True
            self.chapterTable.setRowHidden(r, hide)

    def start_download_clicked(self):
        chapters = []
        for r in range(self.chapterTable.rowCount()):
            if self.chapterTable.isRowHidden(r): continue
            if self.chapterTable.item(r,0).checkState() == Qt.CheckState.Checked:
                ch = self.chapterTable.item(r,0).data(Qt.ItemDataRole.UserRole)
                chapters.append(ch)
        if not chapters:
            QMessageBox.information(self, "提示", "请先勾选要下载的章节。")
            return
        if not self.current_topic:
            QMessageBox.warning(self, "提示", "请先选择漫画。")
            return
        self.lock_ui(True)
        self.totalProgress.setValue(0)
        for r in range(self.chapterTable.rowCount()):
            if self.chapterTable.item(r,0).checkState() == Qt.CheckState.Checked:
                self.chapterTable.item(r,4).setText("下载中")
                self.chapterTable.item(r,6).setText("")
        self.worker = DownloadWorker(self.adapter, self.current_topic.title, chapters)
        self.worker.sigLog.connect(self.log)
        self.worker.sigChapterStarted.connect(self.on_chapter_started)
        self.worker.sigProgress.connect(self.on_progress)
        self.worker.sigChapterDone.connect(self.on_chapter_done)
        self.worker.sigChapterFailed.connect(self.on_chapter_failed)
        self.worker.sigAllDone.connect(self.on_all_done)
        self.worker.start()

    def on_chapter_started(self, ch: dict):
        for r in range(self.chapterTable.rowCount()):
            row_ch = self.chapterTable.item(r,0).data(Qt.ItemDataRole.UserRole)
            if row_ch.get("order")==ch.get("order"):
                self.chapterTable.item(r,4).setText("下载中")
                break

    def on_progress(self, chapter_idx: int, done: int, total: int):
        ch = self.worker.chapters[chapter_idx]
        for r in range(self.chapterTable.rowCount()):
            row_ch = self.chapterTable.item(r,0).data(Qt.ItemDataRole.UserRole)
            if row_ch.get("order")==ch.get("order"):
                item = self.chapterTable.item(r,5)
                item.setText(f"{done}/{total}")
                item.setData(Qt.ItemDataRole.UserRole, done)
                item.setData(Qt.ItemDataRole.UserRole+1, total)
                break
        # total progress as average across chapters
        total_ch = len(self.worker.chapters)
        accum = 0
        for i in range(total_ch):
            row = i  # approximate: treat earlier chapters finished -> 100%, current ratio else 0
        perc = int(((chapter_idx) / max(1, total_ch)) * 100)
        self.totalProgress.setValue(min(perc, 100))

    def on_chapter_done(self, chapter_idx: int):
        ch = self.worker.chapters[chapter_idx]
        for r in range(self.chapterTable.rowCount()):
            row_ch = self.chapterTable.item(r,0).data(Qt.ItemDataRole.UserRole)
            if row_ch.get("order")==ch.get("order"):
                self.chapterTable.item(r,4).setText("已完成")
                break

    def on_chapter_failed(self, chapter_idx: int, msg: str):
        ch = self.worker.chapters[chapter_idx]
        for r in range(self.chapterTable.rowCount()):
            row_ch = self.chapterTable.item(r,0).data(Qt.ItemDataRole.UserRole)
            if row_ch.get("order")==ch.get("order"):
                self.chapterTable.item(r,4).setText("失败")
                self.chapterTable.item(r,6).setText(msg)
                break

    def on_all_done(self):
        self.log("全部任务完成")
        self.lock_ui(False)

    def pause_clicked(self):
        if self.worker:
            self.worker.pause()
            self.btnPause.setEnabled(False)
            self.btnResume.setEnabled(True)

    def resume_clicked(self):
        if self.worker:
            self.worker.resume()
            self.btnPause.setEnabled(True)
            self.btnResume.setEnabled(False)

    def cancel_clicked(self):
        if self.worker:
            self.worker.cancel()

    def lock_ui(self, locked: bool):
        self.btnFetch.setDisabled(locked)
        self.btnStart.setDisabled(locked)
        self.btnPause.setEnabled(locked)
        self.btnResume.setEnabled(False)
        self.btnCancel.setEnabled(locked)
        self.libraryList.setDisabled(locked)
        self.search.setDisabled(locked)
        self.toggleShowAll.setDisabled(locked)

    def open_settings(self):
        dlg = SettingsDialog(self.s, self)
        if dlg.exec():
            self.s = dlg.get()
            self.s.save(self.settings_path)
            self.lib = Library(self.s.save_root, self.data_dir)
            self.refresh_library()


    def add_topic_dialog(self):
        from PyQt6.QtWidgets import QInputDialog
        title, ok = QInputDialog.getText(self, "新增漫画", "漫画标题：")
        if not ok or not title.strip():
            return
        url, ok2 = QInputDialog.getText(self, "新增漫画", "专题URL（快看）：")
        if not ok2 or not url.strip():
            return
        self.lib.upsert_topic("kuaikan", title.strip(), url.strip(), os.path.join(self.s.save_root, title.strip()))
        self.refresh_library()
        self.log(f"已新增：{title}")

    def set_topic_url_dialog(self):
        if not self.current_topic:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.information(self, "提示", "请先从左侧选择一个漫画，再设置URL。")
            return
        from PyQt6.QtWidgets import QInputDialog
        url, ok = QInputDialog.getText(self, "设置URL", "专题URL（快看）：", text=self.current_topic.topic_url or "")
        if not ok or not url.strip():
            return
        self.lib.upsert_topic("kuaikan", self.current_topic.title, url.strip(), os.path.join(self.s.save_root, self.current_topic.title))
        self.current_topic.topic_url = url.strip()
        self.log("URL 已更新")
