
from __future__ import annotations
import os, json, re
from dataclasses import dataclass
from typing import List, Dict, Optional

LIB_FILE = "library.json"

@dataclass
class Topic:
    site: str
    title: str
    topic_url: Optional[str] = None
    author: str = ""
    cover: str = ""
    save_dir: str = ""

@dataclass
class ChapterEntry:
    order: int
    title: str
    episode_no: Optional[str] = None
    url: str = ""
    downloaded_files: int = 0
    total_files: int = 0
    paid_flag: int = 0

class Library:
    def __init__(self, save_root: str, data_dir: str):
        self.save_root = save_root
        self.db_path = os.path.join(data_dir, LIB_FILE)
        self.data = {"topics": {}}
        if os.path.exists(self.db_path):
            try:
                self.data = json.load(open(self.db_path, "r", encoding="utf-8"))
            except Exception:
                pass

    def save(self):
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        json.dump(self.data, open(self.db_path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

    def list_topics(self, site: str) -> List[Topic]:
        out: List[Topic] = []
        for k, v in self.data.get("topics", {}).items():
            if v.get("site") == site:
                out.append(Topic(**v))
        # also scan filesystem for missing
        site_root = os.path.join(self.save_root)
        if os.path.isdir(site_root):
            for title in os.listdir(site_root):
                p = os.path.join(site_root, title)
                if os.path.isdir(p):
                    key = f"{site}:{title}"
                    if key not in self.data["topics"]:
                        self.data["topics"][key] = dict(site=site, title=title, save_dir=p)
                        out.append(Topic(site=site, title=title, save_dir=p))
        return sorted(out, key=lambda t: t.title)

    def upsert_topic(self, site: str, title: str, topic_url: Optional[str], save_dir: str, author: str=""):
        key = f"{site}:{title}"
        self.data.setdefault("topics", {})
        self.data["topics"][key] = dict(site=site, title=title, topic_url=topic_url, save_dir=save_dir, author=author)
        self.save()

    def scan_chapters_local(self, site: str, title: str) -> Dict[str, ChapterEntry]:
        # Scan local folder to infer downloaded chapters and files count.
        base = os.path.join(self.save_root, title)
        result: Dict[str, ChapterEntry] = {}
        if not os.path.isdir(base):
            return result
        for name in os.listdir(base):
            fp = os.path.join(base, name)
            if not os.path.isdir(fp):
                continue
            # name like "001  第1话 标题"
            m = re.match(r"(\d+)", name.strip())
            order = int(m.group(1)) if m else 0
            files = [x for x in os.listdir(fp) if x.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))]
            result[name] = ChapterEntry(order=order, title=name, episode_no=None, url="", downloaded_files=len(files), total_files=max(len(files), 0))
        return result
